## Submission Structure

The main report is located in `MATH-441-Learning-Portfolio.pdf` which is the aggregated file of all artifacts. The source code (Jupyter notebooks, individually rendered PDFs, references) are in each of the dedicated folders which ccan be run using a Python environment. The cover letter and grade proposal are present in the main report.

